﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MAS_AutomationServiceTests
{
    [TestClass]
    public class AutomationServiceTest
    {
    }
}
