﻿namespace Ferretto.VW.MAS_DataLayer
{
    public enum ConfigurationValueEnum : long
    {
        homingCreepSpeed,
        homingFastSpeed,
    }
}
