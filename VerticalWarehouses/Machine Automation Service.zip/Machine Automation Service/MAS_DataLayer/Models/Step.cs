﻿namespace Ferretto.VW.MAS_DataLayer
{
    public class Step
    {
        #region Properties

        public Operation Operation { get; set; }

        public int StepId { get; set; }

        #endregion Properties
    }
}
