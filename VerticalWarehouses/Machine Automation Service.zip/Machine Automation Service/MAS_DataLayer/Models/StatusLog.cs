﻿namespace Ferretto.VW.MAS_DataLayer
{
    public class StatusLog
    {
        #region Properties

        public string LogMessage { get; set; }

        public int StatusLogId { get; set; }

        #endregion Properties
    }
}
