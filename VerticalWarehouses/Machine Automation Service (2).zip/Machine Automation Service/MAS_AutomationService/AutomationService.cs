﻿using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using Ferretto.VW.Common_Utils.EventParameters;
using Ferretto.VW.Common_Utils.Events;
using Ferretto.VW.Common_Utils.Messages;
using Ferretto.VW.MAS_AutomationService.Hubs;
using Ferretto.VW.MAS_AutomationService.Interfaces;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Hosting;
using Prism.Events;

namespace Ferretto.VW.MAS_AutomationService
{
    public class AutomationService : BackgroundService
    {
        #region Fields

        private readonly IEventAggregator eventAggregator;

        private readonly IHubContext<InstallationHub, IInstallationHub> hub;

        private readonly ConcurrentQueue<Event_Message> messageQueue;

        private readonly ManualResetEventSlim messageReceived;

        #endregion

        #region Constructors

        public AutomationService( IEventAggregator eventAggregator, IHubContext<InstallationHub, IInstallationHub> hub )
        {
            this.eventAggregator = eventAggregator;
            this.hub = hub;

            this.messageReceived = new ManualResetEventSlim( false );

            this.messageQueue = new ConcurrentQueue<Event_Message>();

            var inverterNotificationEvent = this.eventAggregator.GetEvent<InverterDriver_NotificationEvent>();
            inverterNotificationEvent.Subscribe( this.SendMessageToAllConnectedClients, ThreadOption.BackgroundThread, false, message => message.OperationStatus == OperationStatus.End );

            var webApiMessagEvent = this.eventAggregator.GetEvent<MachineAutomationService_Event>();
            webApiMessagEvent.Subscribe( ( message ) =>
                {
                    this.messageQueue.Enqueue( message );
                    this.messageReceived.Set();
                },
                ThreadOption.PublisherThread,
                false,
                message => message.Source == MessageActor.WebAPI );
        }

        #endregion

        #region Methods

        public void SendMessageToAllConnectedClients( Notification_EventParameter eventParameter )
        {
            this.hub.Clients.All.OnSendMessageToAllConnectedClients( eventParameter.Description );
        }

        public new Task StopAsync( CancellationToken stoppingToken )
        {
            var returnValue = base.StopAsync( stoppingToken );

            return returnValue;
        }

        public async void TESTStartCycle()
        {
            while(true)
            {
                var message = new string[] { "pippo", "topolino", "pluto", "paperino", "minnie", "qui", "quo", "qua" };
                var randomInt = new Random().Next( message.Length );
                Console.WriteLine( message[randomInt] );
                await this.hub.Clients.All.OnSendMessageToAllConnectedClients( message[randomInt] );
                await Task.Delay( 1000 );
            }
        }

        protected override Task ExecuteAsync( CancellationToken stoppingToken )
        {
            do
            {
                try
                {
                    this.messageReceived.Wait( Timeout.Infinite, stoppingToken );
                }
                catch(OperationCanceledException ex)
                {
                    return Task.CompletedTask;
                }

                this.messageReceived.Reset();

                while(this.messageQueue.TryDequeue( out var receivedMessage ))
                {
                    switch(receivedMessage.Type)
                    {
                        case MessageType.AddMission:
                            PorocessAddMissionMessage( receivedMessage );
                            break;

                        case MessageType.HorizontalHoming:
                            break;
                    }
                }
            } while(!stoppingToken.IsCancellationRequested);

            return StopAsync( stoppingToken );
        }

        private void PorocessAddMissionMessage( Event_Message message )
        {
            //TODO apply Automation Service Business Logic to the message

            message.Source = MessageActor.AutomationService;
            message.Destination = MessageActor.MissionScheduler;
            this.eventAggregator.GetEvent<MachineAutomationService_Event>().Publish( message );
        }

        #endregion
    }
}
