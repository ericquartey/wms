﻿namespace Ferretto.VW.MAS_DataLayer
{
    public enum RuntimeValueEnum : long
    {
        homingDone,
    }
}
