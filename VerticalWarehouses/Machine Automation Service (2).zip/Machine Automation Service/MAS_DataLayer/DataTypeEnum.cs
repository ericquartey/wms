﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ferretto.VW.MAS_DataLayer
{
    public enum DataTypeEnum : long
    {
        integerType,
        decimalType,
        stringType,
    }
}
