﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Ferretto.Common.Common_Utils;
using Ferretto.VW.MAS_InverterDriver;
using Moq;
using Prism.Events;

namespace MAS_InverterDriverUnitTests
{
    [TestClass]
    public class InverterDriverTest
    {
        #region Method

        [TestMethod]

        public void InverterDriver()
        {
        }

        #endregion Method
    }
}
