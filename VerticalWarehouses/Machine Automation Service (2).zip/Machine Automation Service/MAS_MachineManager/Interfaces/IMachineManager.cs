﻿namespace Ferretto.VW.MAS_MachineManager
{
    public interface IMachineManager
    {
    }
}
